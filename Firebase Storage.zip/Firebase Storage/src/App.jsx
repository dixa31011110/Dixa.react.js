
import './App.css'
import Navbar from './components/Navbar'
import Allroutes from './Allroutes'

function App() {
  

  return (
    <>
      <Navbar />
      <Allroutes />
    </>
  )
}

export default App
